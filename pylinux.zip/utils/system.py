import psutil

def get_cpu_usage():
    return psutil.cpu_percent(interval=1)

def get_memory_usage():
    mem = psutil.virtual_memory()
    return {
        "total": mem.total,
        "available": mem.available,
        "used": mem.used,
        "free": mem.free,
        "percent": mem.percent
    }

def get_disk_usage():
    partitions = psutil.disk_partitions()
    disk_usage = {}
    for partition in partitions:
        try:
            usage = psutil.disk_usage(partition.mountpoint)
            disk_usage[partition.mountpoint] = {
                "total": usage.total,
                "used": usage.used,
                "free": usage.free,
                "percent": usage.percent
            }
        except Exception as e:
            print(f"Error reading disk {partition.mountpoint}: {e}")
    return disk_usage

def get_system_load():
    return psutil.getloadavg()

if __name__ == "__main__":
    print("CPU Usage:", get_cpu_usage(), "%")
    print("Memory Usage:", get_memory_usage())
    print("Disk Usage:", get_disk_usage())
    print("System Load:", get_system_load())
